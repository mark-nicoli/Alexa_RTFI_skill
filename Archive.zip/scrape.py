import mechanize
import requests
from bs4 import BeautifulSoup

browser.open('https://www.irishrail.ie')
