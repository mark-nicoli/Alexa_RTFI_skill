from distutils.core import setup
setup(name='db_paw',
      version='1.0',
      py_modules=['foo'],
      )